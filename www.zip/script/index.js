function show_item(id) {
	var spis = document.getElementsByClassName('vis');
	for (var i=0; i<spis.length; i++) {
		spis[i].style.display = "none";
	}
	document.getElementById(id).style.display = "block";
}